package one.digitalinnovation.finals;

public final class HardcoreGamer {

}
